class PhotoClass {

    #user
    #id
    #description

    constructor(user, id, description) {
        this.#user = user;
        this.#id = id;
        this.#description = description;
    }

    get user() {
        return this.#user;
    }
    get id() {
        return this.#id;
    }
    get description() {
        return this.#description;
    }
    set user(user) {
        this.#user = user;
    }
    set id(id) {
        this.#id = id;
    }
    set description(description) {
        this.#description = description;
    }

}

