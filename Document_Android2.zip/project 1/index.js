document.getElementById('goButton').addEventListener('click', async () => {
    try {
        const response = await fetch('http://jsonplaceholder.typicode.com/photos');

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        const arrPhotos = data.slice(0, 10);

        arrPhotos.forEach(photo => {
            const cardContainer = document.createElement('div');
            cardContainer.classList.add('card');
            cardContainer.style.margin = '10px';

            const h3Title = document.createElement('h3');
            h3Title.innerText = photo.title;

            const pId = document.createElement('p');
            pId.innerText = `ID: ${photo.id}`;

            const pUserId = document.createElement('p');
            pUserId.innerText = `UserId: ${photo.albumId}`;

            cardContainer.appendChild(h3Title);
            cardContainer.appendChild(pId);
            cardContainer.appendChild(pUserId);

            document.getElementById('svgcntainer').appendChild(cardContainer);
        });
    } catch (error) {
        console.error('fetch error', error);
    }
});


