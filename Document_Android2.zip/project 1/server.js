const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());

app.get('/photos', async (req, res) => {
    try {
        const apiRes = await fetch('http://jsonplaceholder.typicode.com/photos');

        if (!apiRes.ok) {
            throw new Error(`HTTP error! status: ${apiRes.status}`);
        }

        const data = await apiRes.json();

        res.json(data);
    } catch (error) {
        console.error('fetch error');
        res.status(500).send('internal server error');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});